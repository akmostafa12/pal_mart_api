<?php

namespace App\Http\Controllers;

use App\Models\iceCreamGlocoze;
use App\Models\iceCreamLactoze;
use Exception;
use Illuminate\Http\Client\Request;

abstract class Controller
{
    //
   
}
